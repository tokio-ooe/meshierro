# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '21a04953dbb08a675d4619943ffa1c38d48e84e3201534bee8bda625753d834ed767a8d80f193016972a4b84223971553354108eff9c99680e7278f1b263ce66'